#!/usr/bin/env python3
"""
H_AB construction via second-quantization RDM contraction.

Computes H_AB matrix elements directly from Schmidt-basis transition
matrices and integrals, without CI expansion.

Key physics: B-space operators pick up Jordan-Wigner factor (-1)^{n_A}
when passing through A-space electrons in the sorted Fock basis.
"""

import numpy as np
from typing import Dict


# ═══════════════════════════════════════════════════════════════════════════
# Jordan-Wigner sign
# ═══════════════════════════════════════════════════════════════════════════

def _jw(n_A_cur: int) -> int:
    """Jordan-Wigner sign for one B-operator: (-1)^{n_A_cur}."""
    return 1 if (n_A_cur % 2 == 0) else -1


def _add_to_hab(H_AB, offset_src, offset_dst, r_src, r_dst,
                val_agbd, a_dst, a_src, b_dst, b_src, factor):
    """Safely add a contribution to H_AB."""
    if abs(factor) < 1e-16:
        return
    s = offset_src + a_src * r_src + b_src
    d = offset_dst + a_dst * r_dst + b_dst
    H_AB[d, s] += factor


# ═══════════════════════════════════════════════════════════════════════════
# Main entry point
# ═══════════════════════════════════════════════════════════════════════════

def build_hab_rdm(
    H_AB: np.ndarray,
    schmidt_data: Dict[int, Dict],
    block_offsets: Dict[int, int],
    trans_A,
    trans_B,
    h1_full: np.ndarray,
    h2_full: np.ndarray,
    n_occ: int,
    n_act: int,
    verbose: bool = True,
):
    """Build H_AB matrix via RDM contraction. Fills H_AB in-place."""
    import time

    n_virt = n_act - n_occ

    # Set of all n_A blocks that exist
    all_blocks = sorted(schmidt_data.keys())

    if verbose:
        t0 = time.perf_counter()

    # ── 2e: n_A conserved (2A + 2B, 1-body transitions) ──
    # This is the dominant contribution. We iterate over all integral
    # index assignments with 2 indices in A, 2 in B.
    for n_A in all_blocks:
        sd = schmidt_data[n_A]
        rA_sch = sd['r']
        if rA_sch == 0:
            continue
        os = block_offsets.get(n_A)
        if os is None:
            continue

        TA = trans_A.trans_1.get(n_A)
        TB = trans_B.trans_1.get(n_A)
        if TA is None or TB is None:
            continue

        # Loop over all integral index assignments with exactly 2 in A
        _contract_2e_nA_conserved(
            H_AB, os, n_A, TA, TB, h2_full,
            n_occ, n_act, n_virt, rA_sch
        )

    # ── 2e: n_A → n_A+2 (pair creation in A, pair annihilation in B) ──
    for n_A in all_blocks:
        sd = schmidt_data[n_A]
        sd2 = schmidt_data.get(n_A + 2)
        if sd is None or sd2 is None:
            continue
        rA_src = sd['r']
        rA_dst = sd2['r']
        if rA_src == 0 or rA_dst == 0:
            continue

        TA = trans_A.create_2.get(n_A)
        TB = trans_B.annihilate_2.get(n_A)
        if TA is not None and TB is not None:
            _contract_2e_pair_transfer(
                H_AB, block_offsets, n_A, n_A + 2,
                TA, TB, h2_full, n_occ, n_act, n_virt,
                rA_src, rA_dst, jw_sign=1
            )

    # ── 2e: n_A → n_A-2 (pair annihilation in A, pair creation in B) ──
    for n_A in all_blocks:
        sd = schmidt_data[n_A]
        sd2 = schmidt_data.get(n_A - 2)
        if sd is None or sd2 is None:
            continue
        rA_src = sd['r']
        rA_dst = sd2['r']
        if rA_src == 0 or rA_dst == 0:
            continue

        TA = trans_A.annihilate_2.get(n_A)
        TB = trans_B.create_2.get(n_A)
        if TA is not None and TB is not None:
            _contract_2e_pair_transfer(
                H_AB, block_offsets, n_A, n_A - 2,
                TA, TB, h2_full, n_occ, n_act, n_virt,
                rA_src, rA_dst, jw_sign=1, swap_AB=True
            )

    # ── 1e cross terms ──
    for n_A in all_blocks:
        _add_1e_cross_block_rdm(
            H_AB, block_offsets, n_A, trans_A, trans_B,
            h1_full, n_occ, n_act, n_virt
        )

    if verbose:
        elapsed = time.perf_counter() - t0
        print(f"    H_AB RDM: {elapsed:.1f}s, ||H_AB||={np.linalg.norm(H_AB):.4f}")


# ═══════════════════════════════════════════════════════════════════════════
# 2e: n_A conserved (dominant contribution)
# ═══════════════════════════════════════════════════════════════════════════

def _contract_2e_nA_conserved(
    H_AB, offset_src, n_A_val,
    TA, TB, h2_full,
    n_occ, n_act, n_virt, rA_sch
):
    """Contract 2A+2B with n_A conserved.

    Enumerates all integral index patterns with 2 in A, 2 in B,
    computes JW sign from operator application order, contracts
    TA (A-space 1-body transition) and TB (B-space 1-body transition).
    """
    rA = TA.shape[0]  # Schmidt rank of A
    rB = TB.shape[0]  # Schmidt rank of B

    # Loop over all orbital index combinations
    for p in range(n_act):
        p_in_A = p < n_occ
        for q in range(n_act):
            q_in_A = q < n_occ
            for r in range(n_act):
                r_in_A = r < n_occ  # NOTE: this is a BOOL, different from rA!
                for s in range(n_act):
                    s_in_A = s < n_occ

                    n_in_A = p_in_A + q_in_A + r_in_A + s_in_A
                    if n_in_A != 2:
                        continue

                    # Pure A or B already handled by Path C
                    if n_in_A == 0 or n_in_A == 4:
                        continue

                    integ = h2_full[p, q, r, s]
                    if abs(integ) < 1e-14:
                        continue

                    # Compute JW sign by tracking A-count through
                    # right-to-left operator application
                    cur = n_A_val
                    jw = 1

                    # a_r (rightmost, applied first)
                    if r_in_A:
                        cur -= 1
                    else:
                        jw *= _jw(cur)

                    # a_s (second)
                    if s_in_A:
                        cur -= 1
                    else:
                        jw *= _jw(cur)

                    # a_q† (third)
                    if q_in_A:
                        cur += 1
                    else:
                        jw *= _jw(cur)

                    # a_p† (fourth, leftmost)
                    if p_in_A:
                        cur += 1
                    else:
                        jw *= _jw(cur)

                    # Map to subspace orbital indices
                    p_sub = p if p_in_A else p - n_occ
                    q_sub = q if q_in_A else q - n_occ
                    r_sub = r if r_in_A else r - n_occ
                    s_sub = s if s_in_A else s - n_occ

                    # Determine transition matrix slices
                    # TA[α,γ, a1, a2] where a1, a2 are A-space orbital indices
                    # The operator order within A is determined by the original
                    # positions: A-ops are extracted in left-to-right order

                    # Collect A-operators in Hamiltonian order
                    a_ops = []  # (pos, orbitype) — create or annihilate
                    b_ops = []
                    pos_map = [(p, p_in_A, p_sub), (q, q_in_A, q_sub),
                               (s, s_in_A, s_sub), (r, r_in_A, r_sub)]
                    # pos_map order matches: a_p†, a_q†, a_s, a_r

                    a_indices = []
                    b_indices = []
                    for pos_idx, (in_A, sub_idx) in enumerate(
                            [(p_in_A, p_sub), (q_in_A, q_sub),
                             (s_in_A, s_sub), (r_in_A, r_sub)]):
                        if in_A:
                            a_indices.append(sub_idx)
                        else:
                            b_indices.append(sub_idx)

                    # For TA: two A indices (if exactly 2 in A)
                    # For TB: two B indices
                    if len(a_indices) != 2 or len(b_indices) != 2:
                        continue

                    a1, a2 = a_indices  # first A-op orbital, then second
                    b1, b2 = b_indices

                    # TA slice: TA[:, :, a1, a2] = ⟨Ã_α| O_A(a1, a2) |Ã_γ⟩
                    # where O_A corresponds to the A-operator pattern
                    # TB slice: TB[:, :, b1, b2]
                    ta_slice = TA[:, :, a1, a2]  # (rA, rA)
                    tb_slice = TB[:, :, b1, b2]  # (rB, rB)

                    factor = integ * jw

                    # Add to H_AB
                    for a_dst in range(rA):
                        for a_src in range(rA):
                            ta = ta_slice[a_dst, a_src]
                            if abs(ta) < 1e-15:
                                continue
                            for b_dst in range(rB):
                                for b_src in range(rB):
                                    tb = tb_slice[b_dst, b_src]
                                    if abs(tb) < 1e-15:
                                        continue
                                    v = factor * ta * tb
                                    if abs(v) < 1e-15:
                                        continue
                                    s = offset_src + a_src * rB + b_src
                                    d = offset_src + a_dst * rB + b_dst
                                    H_AB[d, s] += v


# ═══════════════════════════════════════════════════════════════════════════
# 2e: n_A ± 2 (pair transfer)
# ═══════════════════════════════════════════════════════════════════════════

def _contract_2e_pair_transfer(
    H_AB, block_offsets, n_A_src, n_A_dst,
    TA, TB, h2_full, n_occ, n_act, n_virt,
    r_src, r_dst, jw_sign, swap_AB=False
):
    """Contract 2e pair-transfer terms.

    TA: A-space pair creation/annihilation (r_dst, r_src, n_occ, n_occ)
    TB: B-space pair annihilation/creation (rB_dst, rB_src, n_virt, n_virt)

    For n_A→n_A+2 (swap_AB=False):
        Σ_{p,q∈A, r,s∈B} (pq|rs) · TA[α,γ,p,q] · TB[β,δ,r,s]
    For n_A→n_A-2 (swap_AB=True):
        Σ_{p,q∈B, r,s∈A} (pq|rs) · TA[γ,α,p,q] · TB[δ,β,r,s]
    (where TA now stores the A-space annihilation, TB stores B-space creation,
     but the integral pattern is swapped)
    """
    os = block_offsets.get(n_A_src)
    od = block_offsets.get(n_A_dst)
    if os is None or od is None:
        return

    r_dA, r_sA = TA.shape[0], TA.shape[1]
    r_dB, r_sB = TB.shape[0], TB.shape[1]

    if swap_AB:
        # (B,B,A,A): p,q∈B, r,s∈A
        # Integral: (p_in_B, q_in_B | r_in_A, s_in_A) → h2[B,B,A,A]
        for a_dst in range(r_dA):
            for a_src in range(r_sA):
                for b_dst in range(r_dB):
                    for b_src in range(r_sB):
                        val = 0.0
                        for p_sub in range(n_virt):
                            for q_sub in range(n_virt):
                                ta = TA[a_dst, a_src, p_sub, q_sub]
                                if abs(ta) < 1e-15:
                                    continue
                                for r_sub in range(n_occ):
                                    for s_sub in range(n_occ):
                                        tb = TB[b_dst, b_src, r_sub, s_sub]
                                        if abs(tb) < 1e-15:
                                            continue
                                        integ = h2_full[
                                            p_sub + n_occ, q_sub + n_occ,
                                            r_sub, s_sub]
                                        val += integ * ta * tb * jw_sign
                        if abs(val) > 1e-15:
                            s = os + a_src * r_sA + b_src
                            d = od + a_dst * r_dA + b_dst
                            H_AB[d, s] += val
    else:
        # (A,A,B,B): p,q∈A, r,s∈B
        for a_dst in range(r_dA):
            for a_src in range(r_sA):
                for b_dst in range(r_dB):
                    for b_src in range(r_sB):
                        val = 0.0
                        for p_sub in range(n_occ):
                            for q_sub in range(n_occ):
                                ta = TA[a_dst, a_src, p_sub, q_sub]
                                if abs(ta) < 1e-15:
                                    continue
                                for r_sub in range(n_virt):
                                    for s_sub in range(n_virt):
                                        tb = TB[b_dst, b_src, r_sub, s_sub]
                                        if abs(tb) < 1e-15:
                                            continue
                                        integ = h2_full[
                                            p_sub, q_sub,
                                            r_sub + n_occ, s_sub + n_occ]
                                        val += integ * ta * tb * jw_sign
                        if abs(val) > 1e-15:
                            s = os + a_src * r_sA + b_src
                            d = od + a_dst * r_dA + b_dst
                            H_AB[d, s] += val


# ═══════════════════════════════════════════════════════════════════════════
# 1e cross terms
# ═══════════════════════════════════════════════════════════════════════════

def _add_1e_cross_block_rdm(
    H_AB, block_offsets, n_A,
    trans_A, trans_B, h1_full, n_occ, n_act, n_virt
):
    """1e cross: h_pr a_p†(A) a_r(B) + h.c."""
    sd = None  # accessed through block_offsets check

    # h_pr a_p†(A) a_r(B), sign = (-1)^{n_A}
    cre_A = trans_A.create_1.get(n_A)
    ann_B = trans_B.annihilate_1.get(n_A)
    if cre_A is not None and ann_B is not None:
        _add_1e_cross_pair(H_AB, block_offsets, n_A, n_A + 1,
                           cre_A, ann_B, h1_full, n_occ, n_act,
                           jw_sign=_jw(n_A))

    # h_rp a_r†(B) a_p(A), sign = (-1)^{n_A-1}
    ann_A = trans_A.annihilate_1.get(n_A)
    cre_B = trans_B.create_1.get(n_A)
    if ann_A is not None and cre_B is not None:
        _add_1e_cross_pair(H_AB, block_offsets, n_A, n_A - 1,
                           ann_A, cre_B, h1_full, n_occ, n_act,
                           jw_sign=_jw(n_A - 1), transpose_B=True)


def _add_1e_cross_pair(H_AB, block_offsets, n_A_src, n_A_dst,
                       TA, TB, h1_full, n_occ, n_act,
                       jw_sign, transpose_B=False):
    """Add 1e cross contribution for one block pair."""
    os = block_offsets.get(n_A_src)
    od = block_offsets.get(n_A_dst)
    if os is None or od is None:
        return

    r_dA, r_sA = TA.shape[0], TA.shape[1]
    r_dB, r_sB = TB.shape[0], TB.shape[1]

    for a_dst in range(r_dA):
        for a_src in range(r_sA):
            for b_dst in range(r_dB):
                for b_src in range(r_sB):
                    val = 0.0
                    for p in range(n_occ):
                        ta = TA[a_dst, a_src, p]
                        if abs(ta) < 1e-15:
                            continue
                        for r_sub in range(TB.shape[2]):
                            if transpose_B:
                                tb = TB[b_src, b_dst, r_sub]
                            else:
                                tb = TB[b_dst, b_src, r_sub]
                            if abs(tb) < 1e-15:
                                continue
                            r_full = r_sub + n_occ
                            if transpose_B:
                                val += h1_full[r_full, p] * ta * tb * jw_sign
                            else:
                                val += h1_full[p, r_full] * ta * tb * jw_sign
                    if abs(val) > 1e-15:
                        s = os + a_src * r_sA + b_src
                        d = od + a_dst * r_dA + b_dst
                        H_AB[d, s] += val
