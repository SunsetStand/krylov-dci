#!/usr/bin/env python3
"""
H_AB construction via second-quantization RDM contraction.

Uses Jordan-Wigner string factors for correct B-operator signs,
plus within-subspace transition matrices for A and B spaces.
No CI expansion needed.
"""

import numpy as np
from typing import Dict, List


# ═══════════════════════════════════════════════════════════════════════════
# Jordan-Wigner sign for B-space operators
# ═══════════════════════════════════════════════════════════════════════════

def _jw_sign(n_A: int, n_B_ops: int) -> int:
    """Jordan-Wigner sign: B-ops pass through all A-electrons.

    Each B-operator crosses n_A A-electrons → (-1)^{n_A} each.
    For n_B_ops consecutive B-ops: (-1)^{n_A · n_B_ops}.
    """
    return 1 if (n_A * n_B_ops) % 2 == 0 else -1


def _jw_cumulative(a_ops_change: List[int]) -> int:
    """Cumulative JW sign for B-operators in right-to-left application order.

    Args:
        a_ops_change: List of net A-electron changes from A-ops,
            in RIGHT-TO-LEFT application order (annihilators first).
            +1 for A creation, -1 for A annihilation, 0 for B-op.

    Returns:
        Total JW sign product.
    """
    sign = 1
    n_A_cur = 0  # cumulative change from A-ops applied so far
    for delta in reversed(a_ops_change):  # right-to-left
        if delta == 0:  # B-operator
            # n_A_cur is the number of A-ops applied BEFORE this B-op
            # Initial A-count is NOT included here — it gets factored as
            # (-1)^{n_A_initial · n_B_ops} which we compute separately
            # (This function computes the CORRECTION from A-ops that
            #  act between B-operators)
            pass
        else:
            n_A_cur += delta
    # For consecutive B-ops at end (rightmost), A-count = n_A_initial
    # For B-ops after some A-ops, A-count = n_A_initial + n_A_cur
    # The total JW sign = (-1)^{Σ n_A_at_each_B_op}
    return sign


# ═══════════════════════════════════════════════════════════════════════════
# Main H_AB builder
# ═══════════════════════════════════════════════════════════════════════════

def build_hab_rdm(
    H_AB: np.ndarray,
    schmidt_data: Dict[int, Dict],
    block_offsets: Dict[int, int],
    trans_A,
    trans_B,
    h1_full: np.ndarray,
    h2_full: np.ndarray,
    n_occ: int,
    n_act: int,
    verbose: bool = True,
):
    """Build H_AB via second-quantization RDM contraction. In-place on H_AB.

    Physics: for each term in H, factorize A and B operators.
    B-operators pick up (-1)^{n_A_at_application} JW sign.
    A-operators use within-subspace transition matrices.

    For efficiency, contracts transition matrices with integrals:
      Σ_{indices} integral · TA · TB · JW_sign
    """
    n_virt = n_act - n_occ
    B_orb = slice(n_occ, n_act)

    if verbose:
        import time
        t0 = time.perf_counter()

    # ── 1e cross: h_pr a_p†(A) a_r(B) + h.c. ──
    # JW: a_r(B) applied first → (-1)^{n_A_initial}
    #     a_p†(A) applied second → no JW
    for n_A in sorted(schmidt_data.keys()):
        sd_n = schmidt_data[n_A]
        r_n = sd_n['r']
        if r_n == 0:
            continue

        # Check both directions exist
        cre_A = trans_A.create_1.get(n_A)
        ann_B = trans_B.annihilate_1.get(n_A)
        if cre_A is not None and ann_B is not None:
            _add_1e_cross_block(H_AB, n_A, n_A + 1, block_offsets,
                                cre_A, ann_B, h1_full,
                                slice(0, n_occ), B_orb,
                                r_n, r_n,
                                jw_sign=_jw_sign(n_A, 1))  # one B-op at n_A

        ann_A = trans_A.annihilate_1.get(n_A)
        cre_B = trans_B.create_1.get(n_A)
        if ann_A is not None and cre_B is not None:
            # For h_rp a_r†(B) a_p(A): a_p(A) applied first (annihilates in A)
            # Then a_r†(B): JW depends on n_A AFTER annihilation = n_A - 1
            _add_1e_cross_block(H_AB, n_A, n_A - 1, block_offsets,
                                ann_A, cre_B, h1_full,
                                slice(0, n_occ), B_orb,
                                r_n, r_n,
                                jw_sign=_jw_sign(n_A - 1, 1), transpose_B=True)

    # ── 2e: 2A+2B, n_A conserved ──
    # (pq|rs) a_p†(A) a_q†(B) a_s(A) a_r(B) etc.
    # JW calculation: for B-ops at positions 1 and 3 (0-indexed) in the operator string
    #   a_r(B) at pos 3: applied first, A-count = n_A_initial → JW = (-1)^{n_A}
    #   a_q†(B) at pos 1: after a_s(A) has already acted → A-count = n_A - δ_{s∈A}
    # For pattern (A,B,A,B): a_r, a_s both A → A-count = n_A-1 after a_s
    #                         so JW_q = (-1)^{n_A-1}, Total JW = (-1)^{2n_A-1} = -1
    # Wait, I had the wrong result before. Let me reconsider.
    #
    # For (A,B,A,B): p(A), q(B), r(B... wait no. (p,q,r,s) = (A-inA, B-not, A, B-not)
    #   Let me redo this: p∈A, q∈B, r∈A, s∈B
    #   Operator string: a_p†(A) a_q†(B) a_s(A) a_r(B)
    #   Wait no, the operator string is a_p† a_q† a_s a_r with s corresponding to
    #   the FOURTH integral index, and r to the THIRD.
    #   Hmm, I keep confusing this. Let me be very explicit.
    #
    #   Integral: (pq|rs)
    #   Operator: a_p† a_q† a_s a_r
    #   Positions:  p† = 0, q† = 1, s = 2, r = 3
    #   Right-to-left application: pos 3 first (a_r), pos 2 next (a_s),
    #                              pos 1 next (a_q†), pos 0 last (a_p†)
    #
    # For (A,B,A,B): p∈A, q∉A, r∉A(B), s∈A
    #   Wait: r is the THIRD integral index. If (A,B,A,B):
    #     p=0: A, q=1: B, r=2: A, s=3: B
    #   So: p∈A→a_p†(A), q∈B→a_q†(B), r∈A→a_r(A), s∈B→a_s(B)
    #   But wait: r=2 means r is the THIRD index → r∈A, s=3→s∈B
    #   Operator: a_p†(A) a_q†(B) a_s(B) a_r(A)
    #   Right-to-left:
    #     1. a_r(A): annihilates in A → A-count = n_A - 1
    #     2. a_s(B): B-op on state with A-count = n_A - 1 → JW_s = (-1)^{n_A-1}
    #     3. a_q†(B): B-op on state with A-count = n_A - 1 → JW_q = (-1)^{n_A-1}
    #     4. a_p†(A): creates in A → no JW
    #   Total JW = (-1)^{2(n_A-1)} = +1
    #
    # OK so the pattern (A,B,A,B) gives JW = +1, not -1. But earlier with the
    # permutation approach I got -1. The permutation approach was WRONG.
    #
    # Let me compute systematically for all mixed 2e patterns using ONLY JW.

    _add_2e_all_patterns(H_AB, schmidt_data, block_offsets,
                         trans_A, trans_B, h2_full, n_occ, n_act, n_virt)

    if verbose:
        import time
        elapsed = time.perf_counter() - t0
        print(f"    H_AB RDM contraction done in {elapsed:.1f}s")


def _add_1e_cross_block(H_AB, n_A_src, n_A_dst, block_offsets,
                         TA, TB, h1_full, A_slice, B_slice,
                         r_src, r_dst, jw_sign, transpose_B=False):
    """Add 1e cross contribution for one block pair.

    TA: A transition (r_dst_A, r_src_A, n_occ) — create or annihilate.
    TB: B transition (r_dst_B, r_src_B, n_virt) — create or annihilate.
    """
    os = block_offsets.get(n_A_src)
    od = block_offsets.get(n_A_dst)
    if os is None or od is None:
        return

    n_occ = TA.shape[2]
    n_virt = TB.shape[2]

    r_dA, r_sA = TA.shape[0], TA.shape[1]
    r_dB, r_sB = TB.shape[0], TB.shape[1]

    # Contribution: Σ_{p∈A, r∈B} h_pr · TA[α,γ,p] · TB[β,δ,r_B]
    # where r_B = r - n_occ

    for a_dst in range(r_dA):
        for a_src in range(r_sA):
            for b_dst in range(r_dB):
                for b_src in range(r_sB):
                    val = 0.0
                    for p in range(n_occ):
                        ta = TA[a_dst, a_src, p]
                        if abs(ta) < 1e-15:
                            continue
                        for r_sub in range(n_virt):
                            r = r_sub + n_occ
                            if transpose_B:
                                tb = TB[b_src, b_dst, r_sub]  # B† = TB.T for creation
                            else:
                                tb = TB[b_dst, b_src, r_sub]
                            if abs(tb) < 1e-15:
                                continue
                            if transpose_B:
                                # h_rp a_r†(B) a_p(A): integral is h[r,p]
                                val += h1_full[r, p] * ta * tb * jw_sign
                            else:
                                # h_pr a_p†(A) a_r(B)
                                val += h1_full[p, r] * ta * tb * jw_sign
                    if abs(val) > 1e-15:
                        src_flat = os + a_src * r_src + b_src
                        dst_flat = od + a_dst * r_dst + b_dst
                        H_AB[dst_flat, src_flat] += val
                        # H.c.: H_AB[src_flat, dst_flat] += val  (done by symmetrization later)


def _add_2e_all_patterns(H_AB, schmidt_data, block_offsets,
                          trans_A, trans_B, h2_full, n_occ, n_act, n_virt):
    """Add all 2e cross terms by iterating over index patterns."""

    A_range = slice(0, n_occ)
    B_range = slice(n_occ, n_act)

    # Enumerate all non-trivial 2e patterns
    for n_A_src in sorted(schmidt_data.keys()):
        sd_src = schmidt_data[n_A_src]
        r_src = sd_src['r']
        if r_src == 0:
            continue
        os = block_offsets.get(n_A_src)
        if os is None:
            continue

        # ── Pattern 1: (A,A,B,B) — n_A → n_A+2 ──
        # p,q∈A, r,s∈B. JW: both B-ops at n_A → (-1)^{2n_A} = +1
        _contract_2e_pattern(
            H_AB, n_A_src, n_A_src + 2, block_offsets,
            trans_A.create_2.get(n_A_src),
            trans_B.annihilate_2.get(n_A_src),
            h2_full, A_range, B_range, A_range, B_range,
            r_src, 1
        )

        # ── Pattern 2: (B,B,A,A) — n_A → n_A-2 ──
        # p,q∈B, r,s∈A. JW: all A + after two annihilations → n_A-2
        #   a_r(A) first → A-count = n_A-1
        #   a_s(A) second → A-count = n_A-2
        #   a_q†(B) third → JW = (-1)^{n_A-2}
        #   a_p†(B) fourth → JW = (-1)^{n_A-2}
        # Total: (-1)^{2(n_A-2)} = +1
        _contract_2e_pattern(
            H_AB, n_A_src, n_A_src - 2, block_offsets,
            trans_A.annihilate_2.get(n_A_src),
            trans_B.create_2.get(n_A_src),
            h2_full, A_range, B_range, A_range, B_range,
            r_src, 1,
            swap_AB=True
        )

        # ── Pattern 3: 2A+2B, n_A conserved (largest contribution!) ──
        # Multiple sub-patterns:
        # (A,B,A,B): p∈A,q∈B,r∈A,s∈B
        #   a_r(A)→A:n_A-1, a_s(B)→JW=(-1)^{n_A-1}, a_q†(B)→JW=(-1)^{n_A-1}, a_p†(A)→noJW
        #   Total: JW = (-1)^{2(n_A-1)} = +1
        _contract_2e_1body_like(
            H_AB, n_A_src, block_offsets,
            trans_A.trans_1.get(n_A_src),
            trans_B.trans_1.get(n_A_src),
            h2_full, n_occ, n_act, n_virt,
            r_src, n_A_src
        )


def _contract_2e_pattern(H_AB, n_A_src, n_A_dst, block_offsets,
                          TA, TB, h2_full,
                          p_range, q_range, r_range, s_range,
                          r_src, jw_sign, swap_AB=False):
    """Contract TA and TB with integrals for a fixed index pattern."""
    if TA is None or TB is None:
        return
    od = block_offsets.get(n_A_dst)
    os = block_offsets.get(n_A_src)
    if od is None or os is None:
        return

    r_dA, r_sA = TA.shape[0], TA.shape[1]
    r_dB, r_sB = TB.shape[0], TB.shape[1]

    # TA: (r_dA, r_sA, n_occ, n_occ)
    # TB: (r_dB, r_sB, n_virt, n_virt)
    # Contract: Σ_{pq∈A, rs∈B} (pq|rs) · TA[a_dst,a_src,p,q] · TB[b_dst,b_src,r,s_sub]

    n_occ_A = TA.shape[2]
    n_orb_B = TB.shape[2]

    for a_dst in range(r_dA):
        for a_src in range(r_sA):
            for b_dst in range(r_dB):
                for b_src in range(r_sB):
                    val = 0.0
                    for p in range(n_occ_A):
                        for q in range(n_occ_A if not swap_AB else n_orb_B):
                            ta = TA[a_dst, a_src, p, q]
                            if abs(ta) < 1e-15:
                                continue
                            for r_sub in range(n_orb_B):
                                for s_sub in range(n_orb_B):
                                    tb = TB[b_dst, b_src, r_sub, s_sub]
                                    if abs(tb) < 1e-15:
                                        continue
                                    integ = h2_full[p, q, r_sub + p_range.stop if hasattr(p_range,'stop') else n_occ_A,
                                                    s_sub + p_range.stop if hasattr(p_range,'stop') else n_occ_A]
                                    # Actually: integral (p,q|r,s) where p∈A_range, q∈q_range, r∈r_range, s∈s_range
                                    i_p = p
                                    i_q = q
                                    i_r = r_sub + n_occ_A if not isinstance(r_range, slice) or r_range.start >= n_occ_A else r_sub
                                    i_s = s_sub + n_occ_A if not isinstance(s_range, slice) or s_range.start >= n_occ_A else s_sub
                                    # Hmm, this is getting confusing with the range tracking.
                                    # Let me simplify: for (A,A,B,B): p,q∈0..n_occ-1, r,s∈n_occ..n_act-1
                                    # TA indices: p,q ∈ [0, n_occ)
                                    # TB indices: r_sub, s_sub ∈ [0, n_virt) where full r = r_sub + n_occ
                                    pass  # placeholder — will be reimplemented cleanly below


def _contract_2e_1body_like(H_AB, n_A, block_offsets,
                              TA, TB, h2_full, n_occ, n_act, n_virt,
                              r_block, n_A_val):
    """Contract 2A+2B terms with n_A conserved (1-body transitions).

    This handles all index patterns where 2 indices are in A and 2 in B,
    with net n_A change = 0. This is the dominant H_AB contribution.

    The full set of relevant patterns:
    (A,B,A,B): p∈A,q∈B,r∈A,s∈B  → JW = +1
    (A,B,B,A): p∈A,q∈B,r∈B,s∈A  → JW = +1
    (B,A,A,B): p∈B,q∈A,r∈A,s∈B  → JW = +1
    (B,A,B,A): p∈B,q∈A,r∈B,s∈A  → JW = +1

    Wait: we need to be more careful. Let me enumerate the patterns properly:

    (A,B,A,B): p,q,r,s = A,B,A,B
      a_r(A) first → A: n-1, a_s(B) → JW(-1)^{n-1}, a_q†(B) → JW(-1)^{n-1}, a_p†(A) → no JW
      Total JW = (-1)^{2(n-1)} = +1
      O_A = a_p† a_r (1-body), O_B = a_q† a_s (1-body)

    (A,B,B,A): p,q,r,s = A,B,B,A
      a_r(B) first → JW(-1)^n, a_s(A) → no JW, a_q†(B) → JW(-1)^{n-1}, a_p†(A) → no JW
      Total JW = (-1)^{n}·(-1)^{n-1} = -1 
      O_A = a_p† a_s, O_B = a_q† a_r

    (B,A,A,B): p,q,r,s = B,A,A,B
      a_r(A) → n-1, a_s(B) → JW(-1)^{n-1}, a_q†(A) → no JW, a_p†(B) → JW(-1)^{n-1}
      Total JW = (-1)^{2(n-1)} = +1
      O_A = a_q† a_r, O_B = a_p† a_s

    (B,A,B,A): p,q,r,s = B,A,B,A
      a_r(B) → JW(-1)^n, a_s(A) → n-1, a_q†(A) → no JW, a_p†(B) → JW(-1)^{n-1}
      Total JW = (-1)^n·(-1)^{n-1} = -1
      O_A = a_q† a_s, O_B = a_p† a_r

    So two patterns have JW = +1, two have JW = -1.

    For TA (1-body, A-space): TA[α,γ,p,q] = ⟨Ã_α| a_p† a_q |Ã_γ⟩
    For TB (1-body, B-space): TB[β,δ,r,s] = ⟨B̃_β| a_r† a_s |B̃_δ⟩

    The integral pattern determines which orbital pairs to contract:
    (A,B,A,B): Σ_{p,q∈A} Σ_{r,s∈B} (p,q|r,s) TA[p,q]·TB[r,s] → sign +1
    (A,B,B,A): Σ_{p,q∈A} Σ_{r,s∈B} (p,q|s,r) TA[p,q]·TB[r,s] → sign -1
               Note: integral is (p,r|q,s) with original order... 
    
    Hmm, this is getting very messy trying to enumerate patterns. Let me use a DIFFERENT approach.

    The simplest correct approach: compute H_AB by iterating over ALL integral indices
    (p,q,r,s) and decomposing by which subspace each belongs to. For each combination,
    compute the JW sign and contract with the appropriate transition matrices.

    This is O(n_act^4 × D²/r²) which is too slow for large spaces. But for initial
    correctness, let me implement it this way and optimize later.
    """
    if TA is None or TB is None:
        return
    os = block_offsets.get(n_A)
    if os is None:
        return

    rA = TA.shape[0]
    rB = TB.shape[0]

    # Loop over all integral index combinations with 2 in A, 2 in B
    for p in range(n_act):
        pA = p < n_occ
        for q in range(n_act):
            qA = q < n_occ
            for r in range(n_act):
                rA = r < n_occ
                for s in range(n_act):
                    sA = s < n_occ
                    n_in_A = pA + qA + rA + sA
                    if n_in_A == 0 or n_in_A == 4:
                        continue  # pure A or pure B
                    if n_in_A != 2:
                        continue  # only handle n_A conserved for now

                    integ = h2_full[p, q, r, s]
                    if abs(integ) < 1e-14:
                        continue

                    # Compute JW sign from right-to-left operator application
                    # Initial: n_A electrons in A
                    # Step 1: a_r. If r∈A → n-1. If r∈B → JW = (-1)^n
                    # Step 2: a_s. 
                    # Step 3: a_q†.
                    # Step 4: a_p†.

                    n_A_cur = n_A_val
                    jw = 1

                    # a_r (first, rightmost)
                    if rA:
                        n_A_cur -= 1
                    else:
                        jw *= (-1) ** n_A_cur

                    # a_s (second)
                    if sA:
                        n_A_cur -= 1
                    else:
                        jw *= (-1) ** n_A_cur

                    # a_q† (third)
                    if qA:
                        n_A_cur += 1
                    else:
                        jw *= (-1) ** n_A_cur

                    # a_p† (fourth)
                    if pA:
                        n_A_cur += 1
                    else:
                        jw *= (-1) ** n_A_cur

                    if jw == 0:  # should never happen
                        continue

                    # Get A and B transition matrix contributions
                    # Operators: a_p† a_q† a_s a_r
                    # A-ops: extract those with index in A
                    # B-ops: extract those with index in B

                    # Map orbital indices to subspace indices
                    p_sub = p if pA else p - n_occ
                    q_sub = q if qA else q - n_occ
                    r_sub = r if rA else r - n_occ
                    s_sub = s if sA else s - n_occ

                    # A-side contribution
                    if pA and qA and not rA and not sA:
                        # (A,A,B,B): A creates 2, B annihilates 2
                        pass  # Handled by n_A+2 pattern
                    elif not pA and not qA and rA and sA:
                        # (B,B,A,A): A annihilates 2, B creates 2
                        pass  # Handled by n_A-2 pattern
                    elif pA and not qA and rA and not sA:
                        # (A,B,A,B): A: a_p† a_r, B: a_q† a_s
                        # TA[α,γ, p_sub, r_sub], TB[β,δ, q_sub, s_sub]
                        ta_ag = TA[:, :, p_sub, r_sub]  # (rA, rA)
                        tb_bd = TB[:, :, q_sub, s_sub]  # (rB, rB)
                        _add_block_contribution(H_AB, os, rA, rB,
                                                ta_ag, tb_bd, integ * jw)
                    elif pA and not qA and not rA and sA:
                        # (A,B,B,A): A: a_p† a_s, B: a_q† a_r
                        ta_ag = TA[:, :, p_sub, s_sub]
                        tb_bd = TB[:, :, q_sub, r_sub]
                        _add_block_contribution(H_AB, os, rA, rB,
                                                ta_ag, tb_bd, integ * jw)
                    elif not pA and qA and rA and not sA:
                        # (B,A,A,B): A: a_q† a_r, B: a_p† a_s
                        ta_ag = TA[:, :, q_sub, r_sub]
                        tb_bd = TB[:, :, p_sub, s_sub]
                        _add_block_contribution(H_AB, os, rA, rB,
                                                ta_ag, tb_bd, integ * jw)
                    elif not pA and qA and not rA and sA:
                        # (B,A,B,A): A: a_q† a_s, B: a_p† a_r
                        ta_ag = TA[:, :, q_sub, s_sub]
                        tb_bd = TB[:, :, p_sub, r_sub]
                        _add_block_contribution(H_AB, os, rA, rB,
                                                ta_ag, tb_bd, integ * jw)
                    # 3A+1B and 1A+3B patterns: skip for now (need 3-body)


def _add_block_contribution(H_AB, offset, rA, rB,
                             ta_ag, tb_bd, scaled_integ):
    """Add TA·TB·integral to H_AB for a single block."""
    if abs(scaled_integ) < 1e-15:
        return
    for a_dst in range(rA):
        for a_src in range(rA):
            ta = ta_ag[a_dst, a_src]
            if abs(ta) < 1e-15:
                continue
            for b_dst in range(rB):
                for b_src in range(rB):
                    tb = tb_bd[b_dst, b_src]
                    if abs(tb) < 1e-15:
                        continue
                    val = scaled_integ * ta * tb
                    if abs(val) < 1e-15:
                        continue
                    src = offset + a_src * rB + b_src
                    dst = offset + a_dst * rB + b_dst
                    H_AB[dst, src] += val
